# Lenai Description
This package contains the urdf description for the lenai gripper.

## Usage
To visualize the gripper in rviz, run the following command:
```bash
roslaunch lenai_description view.launch
```

### Xacro Macros
To include the gripper in your own urdf, you can use the following xacro macros:
```xml
  <xacro:include filename="$(find lenai_description)/urdf/aloha.urdf.xacro" />
    <link name="aloha_base"/>
    <xacro:aloha_gripper parent="aloha_base">
    <origin rpy="0 0 0" xyz="0 0 0"/>
    </xacro:aloha_gripper>
```
